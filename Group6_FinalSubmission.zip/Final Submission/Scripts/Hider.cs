﻿using UnityEngine;
using System.Collections;

public class Hider : Player {

	// Use this for initialization
	void Start () {
		//Unused, features that use it never implemented
	}
}
